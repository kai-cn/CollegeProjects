package com.example.intelligentbusandroid;

import android.webkit.WebViewClient;
import android.webkit.WebView;

public class BusWebViewClient extends WebViewClient {
	
	public boolean shouldOverUrlLoading(WebView view,String url)
	{
		view.loadUrl(url);
		return true;
	}
}
