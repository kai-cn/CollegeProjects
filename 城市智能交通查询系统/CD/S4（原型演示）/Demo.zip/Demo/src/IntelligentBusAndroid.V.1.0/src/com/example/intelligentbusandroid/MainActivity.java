package com.example.intelligentbusandroid;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;

import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
	private WebView webView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InitWebView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    
    private void InitWebView()
    {
    	webView=(WebView)findViewById(R.id.webview);
    	webView.getSettings().setJavaScriptEnabled(true);
    	
    	//webView.loadUrl("http://192.168.0.141:8080/IntelligentBus.V.1.0/WebRoot/index.jsp");
    	
    	webView.loadUrl("http://192.168.83.1");
    	
    	webView.setWebViewClient(new BusWebViewClient());
    }

    
}
