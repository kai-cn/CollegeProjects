﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data;

namespace IntelligentBus.Persist
{
    public class BusLine
    {
        private NetUtil.DB.DbUtil dbUtil = NetUtil.DB.DbFactory.CreateDbUtil();
        private string selectSqlStr;

        public BusLine()
        {
            selectSqlStr = "select * from BusLine";
        }
        public DataSet Select(int BusLineID)
        {
            string strSql = string.Format("{0} where BusLineID={1}", selectSqlStr, BusLineID);

            return dbUtil.Select(strSql);
        }
    }
}