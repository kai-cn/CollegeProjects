﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntelligentBus.Entities
{

    public class BusLine
    {
        private int areaID;
        private String lineCode;

        public string LineCode
        {
            get {return lineCode; }
            set { lineCode = value; }
        }

        public BusLine(int areaID, String lineCode)
        {
            this.areaID = areaID;
            this.lineCode = lineCode;
        }

        

        public BusLine()
        {
            
        }

    }
}