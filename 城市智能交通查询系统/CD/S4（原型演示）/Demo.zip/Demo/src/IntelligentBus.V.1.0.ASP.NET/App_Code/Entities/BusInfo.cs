﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntelligentBus.Entities
{

    public class BusInfo
    {

        private int buslineID;
        private int startTime;
        private int endTime;
        private int lastStartTime;
        private string otherInfo;
        private int lastEndTime;

        public BusInfo(int buslineID, int startTime, int endTime)
        {
            this.buslineID = buslineID;
            this.startTime = startTime;
            this.endTime = endTime;
        }

        public int BusLineID
        {
            get {return buslineID; }
            set { buslineID = value; }
        }


        public BusInfo(int busLineID)
        {
            this.buslineID = busLineID;
        }


    }
}
